import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actfij',
  templateUrl: './actfij.page.html',
  styleUrls: ['./actfij.page.scss'],
})
export class ActfijPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
